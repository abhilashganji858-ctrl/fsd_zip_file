# TicketTamer v2: SLASlayer Hack

Customer support ticketing with priority-based SLA countdowns, a Kanban agent workspace and a manager analytics dashboard. Version 2 adds a Node.js + Express backend with SQLite, real sign-in, server-side validation, pagination and automated tests.

## What changed in v2

| Feedback from the evaluation | What v2 does |
|---|---|
| Implement the Node.js/Express backend | Express API in `server/`, tickets stored in SQLite, escalation timer running on the server |
| Add automated unit tests for the SLA logic | 38 tests with Node's built-in test runner covering SLA, sanitizing, stats, auth and the whole service layer |
| Proper input sanitization | Text is cleaned on the server (tags and control characters removed, length limits, whitespace normalized) and escaped again when rendered; the same rules run in the browser form |
| Split the frontend into modules | ES modules in `public/js/`, one per screen, plus `shared/` code used by browser, server and tests |
| Scalability and pagination | Paginated API (`page`, `pageSize` up to 50), indexed queries, "Show more" on every board column |
| No real authentication | Username and password sign-in, scrypt-hashed passwords, signed HttpOnly session cookie, roles enforced on the server |
| Minimal error handling | Consistent JSON errors, field-level validation messages, toasts for failures, expired sessions return to the sign-in page |

## Requirements

- Node.js 22.13 or newer (uses the built-in `node:sqlite` module)
- npm

## Run it

```bash
npm install
npm start
```

Open http://localhost:3000. The first start creates `data/tickettamer.db` with demo users and 20 sample tickets.

Demo accounts (password for all: `TicketTamer!23`):

| Role | Usernames |
|---|---|
| Customer | `dana`, `omar`, `lena`, `ravi`, `chloe` |
| Agent | `asha`, `marcus`, `priya`, `tomas`, `jun` |
| Manager | `manager` |

Other commands:

```bash
npm test          # run all unit tests
npm run dev       # restart the server when files change
npm run reset-db  # delete the database; it is recreated with demo data on next start
```

Environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | 3000 | HTTP port |
| `DB_FILE` | `data/tickettamer.db` | SQLite file location |
| `SESSION_SECRET` | random per start | Signs session cookies. Set it so sign-ins survive restarts |
| `NODE_ENV` | unset | Set to `production` to mark cookies `Secure` (needs HTTPS) |

## Roles

| Role | Can do |
|---|---|
| Customer | Submit tickets, see only their own tickets, rate resolved tickets |
| Agent | Everything above, plus the board, replies, notes, stage changes, claiming tickets for themselves, analytics |
| Manager | Everything an agent can do, plus assigning tickets to any agent and auto-assigning new tickets by workload |

## Demo flow

1. Sign in as `dana` (Customer) and submit "Payment Gateway Crash". It becomes Urgent with a 2-hour clock.
2. Sign out and sign in as `asha` (Agent). The ticket is in New / Unassigned. Click **Claim**.
3. Open the ticket, pick a canned reply, send it, add the note "Patched gateway webhook listener" and set it to Resolved.
4. Sign in as `dana` again and rate the ticket.
5. Sign in as `manager` and open Manager Analytics to see compliance and response time update.

## Features

- Ticket form with category, priority and description, validated in the browser and on the server
- Automatic priority: "crash", "outage", "data loss", "payment failed" raise to Urgent; "cannot login", "locked out", "refund" raise to High. Priority is never lowered
- SLA deadlines: Urgent 2h, High 4h, Normal 24h, Low 48h
- Live countdown badges: green (safe), amber (under half the time left), red (breached). One timer updates every badge every 10 seconds, using the server's clock so a wrong device clock cannot distort it
- Kanban board with four stages, each column sorted by closest deadline and paginated
- Ticket state machine enforced on the server (for example, a resolved ticket can only be reopened)
- Agent workload bars and manager auto-assign
- Canned replies, reply threads and internal resolution notes (hidden from customers)
- CSAT 5-star rating, limited to the ticket owner, once, after resolution
- Analytics: Total Tickets, SLA Compliance %, Mean Response Time, Open Breaches, compliance donut, category chart, hourly volume chart, agent efficiency table
- Light and dark themes, responsive layout

## Project structure

```
tickettamer/
├── package.json
├── server/
│   ├── index.js     starts the server and the SLA escalation timer
│   ├── app.js       Express routes, security headers, sessions
│   ├── service.js   business rules (no HTTP), fully unit tested
│   ├── db.js        SQLite schema, indexes and demo data
│   ├── auth.js      password hashing, signed tokens, login rate limit
│   └── reset.js     deletes the database file
├── shared/          imported by server, browser and tests
│   ├── sla.js       SLA windows, state machine, priority rules, countdown state
│   ├── sanitize.js  text cleaning and ticket validation
│   ├── stats.js     KPIs and efficiency index
│   └── canned.js    canned replies
├── public/
│   ├── index.html
│   ├── css/style.css
│   └── js/          main.js, api.js, badge.js, dom.js, session.js, ui/ (login, portal, board, dialogs, analytics)
└── tests/           *.test.js
```

## API

All routes are under `/api` and return JSON. Mutating requests must send `Content-Type: application/json`.

| Method and path | Who | Purpose |
|---|---|---|
| `GET /me` | anyone | Current user or `null` |
| `POST /login`, `POST /logout` | anyone | Sign in and out |
| `GET /tickets?status&page&pageSize` | signed in | Paginated list (customers see only their own) |
| `POST /tickets` | signed in | Create a ticket |
| `GET /tickets/:id` | signed in | Ticket with replies |
| `PATCH /tickets/:id` | agent, manager | Change `status`, `agent` or `notes` |
| `POST /tickets/:id/replies` | agent, manager | Add a reply |
| `POST /tickets/:id/csat` | ticket owner | Rate a resolved ticket |
| `POST /tickets/auto-assign` | manager | Assign new tickets by workload |
| `GET /agents` | agent, manager | Agent workload |
| `GET /stats` | agent, manager | Analytics data |

## Security notes

- Passwords are hashed with scrypt and a random salt; login compares in constant time and is rate limited (10 failures per 15 minutes per address)
- Sessions use a signed, expiring token in an `HttpOnly`, `SameSite=Strict` cookie. The user's role is reloaded from the database on every request
- Every route checks the role on the server; the interface hiding buttons is only a convenience
- Queries use parameters, never string-built user input
- A Content Security Policy limits scripts to this site and the Chart.js CDN, and the interface escapes all text it renders
- The demo password is public. Change or remove the seeded accounts before any real deployment

## Testing

`npm test` runs 38 tests (SLA boundaries, keyword priority, sanitizing, auth tokens, pagination, permissions, the state machine, CSAT rules, the escalation scan and analytics). Tests use an in-memory SQLite database and need no extra packages.

## Known limits

- SQLite and the in-memory login limiter suit a single server. A larger deployment would move to a shared database and store
- Analytics are computed from all tickets on each request; add SQL aggregates if the volume grows large
- No password reset, email notifications or customer reply threads yet
- Chart.js and Google Fonts load from CDNs; without internet the charts do not draw (KPIs and tables still work)
