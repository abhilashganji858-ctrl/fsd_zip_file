// Thin fetch wrapper. Also tracks the offset between the server clock and this browser's clock,
// so SLA countdowns stay correct even if the device clock is wrong.
let offset = 0;
export const serverNow = () => Date.now() + offset;

async function call(method, url, body) {
  const res = await fetch(url, {
    method,
    credentials: 'same-origin',
    headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' },
    body: method === 'GET' ? undefined : JSON.stringify(body ?? {}),
  });
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (data.serverTime) offset = data.serverTime - Date.now();
  if (!res.ok) {
    if (res.status === 401 && url !== '/api/login') window.dispatchEvent(new Event('session-expired'));
    const err = new Error(data.error || `Request failed (${res.status})`);
    err.status = res.status;
    err.details = data.details;
    throw err;
  }
  return data;
}

export const api = {
  me: () => call('GET', '/api/me'),
  login: (username, password) => call('POST', '/api/login', { username, password }),
  logout: () => call('POST', '/api/logout'),
  tickets: (query) => call('GET', `/api/tickets?${new URLSearchParams(query)}`),
  ticket: (id) => call('GET', `/api/tickets/${id}`),
  createTicket: (body) => call('POST', '/api/tickets', body),
  update: (id, patch) => call('PATCH', `/api/tickets/${id}`, patch),
  reply: (id, text) => call('POST', `/api/tickets/${id}/replies`, { text }),
  rate: (id, rating) => call('POST', `/api/tickets/${id}/csat`, { rating }),
  autoAssign: () => call('POST', '/api/tickets/auto-assign'),
  agents: () => call('GET', '/api/agents'),
  stats: () => call('GET', '/api/stats'),
};
