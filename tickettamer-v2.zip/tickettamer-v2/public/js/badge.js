import { slaState } from '/shared/sla.js';
import { serverNow } from './api.js';
import { $$, esc } from './dom.js';

const known = new Map(); // ticket id -> latest ticket data, used by the timer

export function badge(ticket) {
  known.set(ticket.id, ticket);
  const s = slaState(ticket, serverNow());
  return `<span class="b ${s.state}${s.final ? '' : ' live'}" data-sla="${ticket.id}">${esc(s.label)}</span>`;
}

/** One centralized timer updates every countdown badge in the DOM. */
export function startSlaTimer(intervalMs = 10_000) {
  return setInterval(() => {
    for (const el of $$('[data-sla]')) {
      const ticket = known.get(Number(el.dataset.sla));
      if (!ticket) continue;
      const s = slaState(ticket, serverNow());
      el.className = `b ${s.state}${s.final ? '' : ' live'}`;
      el.textContent = s.label;
    }
  }, intervalMs);
}
