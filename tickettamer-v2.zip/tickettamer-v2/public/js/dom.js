import { escapeHtml } from '/shared/sanitize.js';

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
export const esc = escapeHtml;

export const options = (list, selected) => list.map((v) => `<option${v === selected ? ' selected' : ''}>${esc(v)}</option>`).join('');

let toastTimer;
export function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.style.display = 'none'; }, 4500);
}

/** Runs an async UI action and shows any error as a toast instead of failing silently. */
export async function guarded(action) {
  try { return await action(); } catch (err) { toast(err.message || 'Something went wrong.'); return undefined; }
}
