import { api } from './api.js';
import { $, $$, guarded } from './dom.js';
import { session, isStaff } from './session.js';
import { startSlaTimer } from './badge.js';
import { initLogin } from './ui/login.js';
import { initPortal, refreshPortal } from './ui/portal.js';
import { initBoard, refreshBoard } from './ui/board.js';
import { refreshAnalytics } from './ui/analytics.js';

const VIEWS = { customer: refreshPortal, agent: refreshBoard, analytics: refreshAnalytics };
let view = 'customer';
let started = false;

function show(name) {
  if (name !== 'customer' && !isStaff()) name = 'customer';
  view = name;
  $$('.view').forEach((el) => el.classList.toggle('on', el.id === `v-${name}`));
  $$('#nav button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === name)));
  try { history.replaceState(null, '', `#${name}`); } catch { /* ignore */ }
  VIEWS[name]();
}

function enterApp(user, restoreHash = false) {
  session.user = user;
  $('#login').hidden = true;
  $('#app').hidden = false;
  $('#who').textContent = `${user.display} (${user.role})`;
  $$('[data-staff]').forEach((b) => { b.hidden = !isStaff(); });
  const wanted = restoreHash ? location.hash.slice(1) : '';
  show(wanted in VIEWS ? wanted : isStaff() ? 'agent' : 'customer');
}

function showLogin() {
  session.user = null;
  try { history.replaceState(null, '', location.pathname); } catch { /* ignore */ }
  $('#app').hidden = true;
  $('#login').hidden = false;
}

function start() {
  if (started) return;
  started = true;
  initLogin((user) => enterApp(user));
  initPortal();
  initBoard();
  startSlaTimer();
  $$('#nav button').forEach((b) => b.addEventListener('click', () => show(b.dataset.v)));
  $('#theme').addEventListener('click', () => {
    const root = document.documentElement;
    root.dataset.theme = getComputedStyle(root).colorScheme === 'dark' ? 'light' : 'dark';
    if (view === 'analytics') refreshAnalytics();
  });
  $('#logout').addEventListener('click', async () => { await guarded(() => api.logout()); showLogin(); });
  window.addEventListener('session-expired', showLogin);
  // Pick up changes made by other people without a manual refresh.
  setInterval(() => { if (session.user && !document.querySelector('dialog[open]') && !document.hidden) VIEWS[view](); }, 30_000);
}

start();
const { user } = await api.me().catch(() => ({ user: null }));
user ? enterApp(user, true) : showLogin();
