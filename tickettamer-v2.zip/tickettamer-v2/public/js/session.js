export const session = { user: null };
export const isStaff = () => session.user?.role === 'agent' || session.user?.role === 'manager';
