import { api } from '../api.js';
import { $, esc, guarded } from '../dom.js';
import { CATEGORIES } from '/shared/sla.js';

let charts = [];

export const refreshAnalytics = () => guarded(async () => {
  const { stats: s } = await api.stats();
  const pct = s.slaCompliancePct == null ? 'n/a' : `${s.slaCompliancePct}%`;
  const frt = s.meanResponseMin == null ? 'n/a' : `${s.meanResponseMin} min`;
  $('#kpis').innerHTML = [['Total Tickets', s.total], ['SLA Compliance', pct], ['Mean Response Time', frt], ['Open Breaches', s.openBreaches]]
    .map(([label, value]) => `<div class="panel kpi"><b>${value}</b><span>${label}</span></div>`).join('');
  $('#eff').innerHTML = '<tr><th>Agent</th><th>Open</th><th>Resolved</th><th>On time</th><th>Avg hrs to resolve</th><th>Index</th></tr>' +
    s.agents.map((a) => `<tr><td>${esc(a.name)}</td><td>${a.open}</td><td>${a.resolved}</td><td>${a.onTime}</td><td>${a.avgHours.toFixed(1)}</td><td><b>${a.index}</b></td></tr>`).join('');
  drawCharts(s);
});

function drawCharts(s) {
  if (!window.Chart) return; // CDN blocked or offline: tables and KPIs still work
  charts.forEach((c) => c.destroy());
  const css = getComputedStyle(document.documentElement);
  const v = (name) => css.getPropertyValue(name).trim();
  Chart.defaults.color = v('--mute');
  Chart.defaults.borderColor = v('--line');
  const base = { responsive: true, maintainAspectRatio: false };
  const noLegend = { ...base, plugins: { legend: { display: false } } };
  const breached = s.openBreaches + (s.agents.reduce((n, a) => n + a.resolved - a.onTime, 0));
  const met = s.agents.reduce((n, a) => n + a.onTime, 0);
  const hours = s.hourly.map((_, i) => (i === 23 ? 'now' : `${23 - i}h`));
  charts = [
    new Chart($('#c1'), { type: 'doughnut', data: { labels: ['Met', 'Breached'], datasets: [{ data: [met, breached], backgroundColor: [v('--ok'), v('--bad')], borderWidth: 0 }] }, options: { ...base, cutout: '65%' } }),
    new Chart($('#c2'), { type: 'bar', data: { labels: CATEGORIES, datasets: [{ label: 'Tickets', data: CATEGORIES.map((c) => s.byCategory[c]), backgroundColor: v('--acc') }] }, options: noLegend }),
    new Chart($('#c3'), { type: 'bar', data: { labels: hours, datasets: [{ label: 'Created', data: s.hourly, backgroundColor: v('--warn') }] },
      options: { ...noLegend, scales: { y: { ticks: { precision: 0 } }, x: { ticks: { maxTicksLimit: 8 } } } } }),
  ];
}
