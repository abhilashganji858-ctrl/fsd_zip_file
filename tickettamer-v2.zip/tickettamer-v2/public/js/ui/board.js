import { api } from '../api.js';
import { $, $$, esc, guarded, toast } from '../dom.js';
import { STATUSES, STATUS_LABELS } from '/shared/sla.js';
import { badge } from '../badge.js';
import { session } from '../session.js';
import { openTicket } from './dialogs.js';

const PAGE_SIZE = 6;
const NEXT = { new: 'progress', progress: 'awaiting', awaiting: 'resolved' };
const columns = Object.fromEntries(STATUSES.map((s) => [s, { items: [], total: 0 }]));
let agents = [];

export function initBoard() {
  $('#board').addEventListener('click', (e) => {
    const d = e.target.dataset;
    if (d.next) guarded(async () => { await api.update(d.next, { status: NEXT[d.from] }); await refreshBoard(); });
    if (d.open) openTicket(Number(d.open), refreshBoard);
    if (d.more) guarded(() => loadColumn(d.more, true).then(render));
  });
  $('#board').addEventListener('change', (e) => {
    if (!e.target.dataset.assign) return;
    guarded(async () => { await api.update(e.target.dataset.assign, { agent: e.target.value || null }); await refreshBoard(); });
  });
  $('#balance').addEventListener('click', () => guarded(async () => {
    const { assigned } = await api.autoAssign();
    toast(assigned ? `${assigned} new ticket${assigned > 1 ? 's' : ''} assigned by workload.` : 'No unassigned tickets.');
    await refreshBoard();
  }));
}

async function loadColumn(status, append = false) {
  const col = columns[status];
  const page = append ? Math.floor(col.items.length / PAGE_SIZE) + 1 : 1;
  const size = append ? PAGE_SIZE : Math.max(PAGE_SIZE, col.items.length);
  const data = await api.tickets({ status, page, pageSize: size });
  col.items = append ? [...col.items, ...data.items] : data.items;
  col.total = data.total;
}

export const refreshBoard = () => guarded(async () => {
  [{ agents }] = await Promise.all([api.agents(), ...STATUSES.map((s) => loadColumn(s))]);
  render();
});

function assignOptions(ticket) {
  const me = session.user;
  // Agents may only pick themselves, but must still see who currently owns the ticket.
  const choices = me.role === 'manager' ? agents : agents.filter((a) => a.username === me.username || a.username === ticket.agent?.username);
  return `<option value="">Unassigned</option>${choices.map((a) =>
    `<option value="${esc(a.username)}"${ticket.agent?.username === a.username ? ' selected' : ''}${me.role === 'agent' && a.username !== me.username ? ' disabled' : ''}>${esc(a.display.split(' ')[0])} (${a.open})</option>`).join('')}`;
}

function render() {
  $('#balance').hidden = session.user.role !== 'manager';
  $('#load').innerHTML = agents.map((a) => `<div class="ag${a.open >= 4 ? ' hot' : ''}"><b>${esc(a.display.split(' ')[0])}</b> ${a.open} open${a.breached ? `, ${a.breached} breached` : ''}
    <div class="bar"><span style="width:${Math.min(100, a.open * 20)}%"></span></div></div>`).join('');
  $('#board').innerHTML = STATUSES.map((s) => {
    const { items, total } = columns[s];
    const cards = items.map((t) => `<article class="card p-${esc(t.pri)}"><div class="m"><b>#${t.id}</b><span class="chip">${esc(t.pri)}</span></div>
      <h4 data-open="${t.id}" tabindex="0">${esc(t.subject)}</h4>
      <div class="m"><span>${esc(t.cat)}</span><span>${esc(t.customer)}</span></div>${badge(t)}
      <div class="row"><select data-assign="${t.id}" aria-label="Assign agent">${assignOptions(t)}</select>
      ${NEXT[s] ? `<button class="ghost small" data-next="${t.id}" data-from="${s}">${s === 'new' ? 'Claim' : 'Next'}</button>` : ''}</div></article>`).join('');
    return `<div class="col"><h3>${esc(STATUS_LABELS[s])}<span>${total}</span></h3>${cards || '<p class="hint">Nothing here.</p>'}
      ${items.length < total ? `<button class="ghost small more" data-more="${s}">Show more (${total - items.length})</button>` : ''}</div>`;
  }).join('');
}
