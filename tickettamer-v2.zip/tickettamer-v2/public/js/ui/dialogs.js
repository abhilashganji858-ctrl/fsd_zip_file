import { api } from '../api.js';
import { $, $$, esc, guarded, toast } from '../dom.js';
import { STATUS_LABELS, TRANSITIONS } from '/shared/sla.js';
import { CANNED } from '/shared/canned.js';
import { badge } from '../badge.js';

/** Staff ticket dialog: thread, canned replies, internal notes, stage changes. */
export async function openTicket(id, onChange) {
  const draw = (t) => {
    const d = $('#dlg');
    d.innerHTML = `<h3>#${t.id} ${esc(t.subject)}</h3><p class="hint">${esc(t.cat)} · ${esc(t.pri)} · ${esc(t.customer)}</p><p>${esc(t.desc)}</p>${badge(t)}
      ${t.replies.map((m) => `<div class="item" style="margin-top:8px"><b>${esc(m.author)}</b><span style="white-space:pre-wrap">${esc(m.body)}</span></div>`).join('')}
      <label style="margin-top:12px">Canned response<select id="can"><option value="">Choose a reply…</option>${Object.keys(CANNED).map((k) => `<option>${esc(k)}</option>`).join('')}</select></label>
      <label style="margin-top:8px">Reply to customer<textarea id="rep" rows="3" maxlength="1000"></textarea></label>
      <label style="margin-top:8px">Resolution notes (internal)<textarea id="nt" rows="2" maxlength="500" placeholder="e.g. Patched gateway webhook listener">${esc(t.notes)}</textarea></label>
      <div class="tools" style="margin:14px 0 0">
        ${TRANSITIONS[t.status].map((s) => `<button class="ghost small" data-to="${s}">${esc(STATUS_LABELS[s])}</button>`).join('')}
        <button class="ghost small" id="save-notes">Save notes</button><button class="primary small" id="send">Send reply</button><button class="ghost small" id="close">Close</button></div>`;
    $('#can', d).onchange = (e) => { $('#rep', d).value = CANNED[e.target.value] || ''; };
    $('#close', d).onclick = () => d.close();
    $('#save-notes', d).onclick = () => guarded(async () => { const r = await api.update(t.id, { notes: $('#nt', d).value }); draw(r.ticket); toast('Notes saved.'); onChange?.(); });
    $('#send', d).onclick = () => guarded(async () => {
      const text = $('#rep', d).value.trim();
      if (!text) return toast('Write a reply first.');
      const r = await api.reply(t.id, text); draw(r.ticket); onChange?.();
    });
    $$('[data-to]', d).forEach((b) => { b.onclick = () => guarded(async () => {
      await api.update(t.id, { notes: $('#nt', d).value });
      const r = await api.update(t.id, { status: b.dataset.to });
      draw(r.ticket); onChange?.();
      if (b.dataset.to === 'resolved') toast('Resolved. The customer can now rate this ticket.');
    }); });
    return d;
  };
  const data = await guarded(() => api.ticket(id));
  if (!data) return;
  const d = draw(data.ticket);
  if (!d.open) d.showModal();
}

/** Customer CSAT prompt for a resolved ticket. */
export function openRating(ticket, onDone) {
  if (!ticket) return;
  let rating = 0;
  $('#csat-t').textContent = `Ticket #${ticket.id} was resolved. How was your support experience?`;
  $('#stars').innerHTML = [1, 2, 3, 4, 5].map((n) => `<button type="button" data-star="${n}" aria-label="${n} star${n > 1 ? 's' : ''}">★</button>`).join('');
  $('#stars').onclick = (e) => {
    const n = Number(e.target.dataset.star);
    if (!n) return;
    rating = n;
    $$('#stars button').forEach((b, i) => b.classList.toggle('on', i < n));
  };
  $('#csat-skip').onclick = () => $('#csat').close();
  $('#csat-go').onclick = () => guarded(async () => {
    if (!rating) return toast('Pick a star rating first.');
    await api.rate(ticket.id, rating);
    $('#csat').close();
    toast('Thanks for your feedback!');
    onDone?.();
  });
  $('#csat').showModal();
}
