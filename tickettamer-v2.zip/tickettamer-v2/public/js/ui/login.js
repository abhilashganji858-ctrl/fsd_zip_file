import { api } from '../api.js';
import { $, $$ } from '../dom.js';

export function initLogin(onSuccess) {
  $$('[data-demo]').forEach((b) => b.addEventListener('click', () => {
    $('#l-user').value = b.dataset.demo;
    $('#l-pass').value = 'TicketTamer!23';
  }));
  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#l-err').textContent = '';
    try {
      const { user } = await api.login($('#l-user').value, $('#l-pass').value);
      $('#l-pass').value = '';
      onSuccess(user);
    } catch (err) {
      $('#l-err').textContent = err.message;
    }
  });
}
