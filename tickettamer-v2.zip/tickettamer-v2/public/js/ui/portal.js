import { api } from '../api.js';
import { $, $$, esc, guarded, options, toast } from '../dom.js';
import { CATEGORIES, PRIORITIES, STATUS_LABELS, SLA_MINUTES, MINUTE, formatDuration } from '/shared/sla.js';
import { validateTicketInput } from '/shared/sanitize.js';
import { badge } from '../badge.js';
import { session, isStaff } from '../session.js';
import { openRating } from './dialogs.js';

const PAGE_SIZE = 6;
let items = [];
let total = 0;

export function initPortal() {
  $('#f-cat').innerHTML = options(CATEGORIES);
  $('#f-pri').innerHTML = options(PRIORITIES, 'Normal');
  $('#form').addEventListener('submit', submitTicket);
  $('#mine-more').addEventListener('click', () => guarded(() => load({ append: true })));
  $('#mine').addEventListener('click', (e) => {
    const id = Number(e.target.dataset.rate);
    if (id) openRating(items.find((t) => t.id === id), refreshPortal);
  });
}

function showFieldErrors(errors = {}) {
  $$('[data-err]').forEach((el) => { el.textContent = errors[el.dataset.err] || ''; });
}

async function submitTicket(e) {
  e.preventDefault();
  const body = { subject: $('#f-subj').value, cat: $('#f-cat').value, pri: $('#f-pri').value, desc: $('#f-desc').value };
  const check = validateTicketInput(body); // instant feedback; the server validates again
  showFieldErrors(check.errors);
  if (!check.ok) return;
  try {
    const { ticket, priorityRaised } = await api.createTicket(body);
    e.target.reset();
    $('#f-pri').value = 'Normal';
    toast(`Ticket #${ticket.id} created as ${ticket.pri}. SLA clock started: ${formatDuration(SLA_MINUTES[ticket.pri] * MINUTE)}.${priorityRaised ? ' Priority was raised automatically.' : ''}`);
    await refreshPortal();
  } catch (err) {
    showFieldErrors(err.details);
    toast(err.message);
  }
}

async function load({ append = false } = {}) {
  const page = append ? Math.floor(items.length / PAGE_SIZE) + 1 : 1;
  const size = append ? PAGE_SIZE : Math.max(PAGE_SIZE, items.length);
  const data = await api.tickets({ page: append ? page : 1, pageSize: size });
  items = append ? [...items, ...data.items] : data.items;
  total = data.total;
  render();
}

export const refreshPortal = () => guarded(() => load());

function render() {
  $('#list-title').textContent = isStaff() ? 'Recent tickets (all customers)' : 'My tickets';
  $('#mine').innerHTML = items.map((t) => `<div class="item"><div class="r"><b>#${t.id} ${esc(t.subject)}</b><span class="chip">${esc(t.pri)}</span></div>
    <div class="r"><span class="hint">${esc(t.cat)}, ${esc(STATUS_LABELS[t.status])}</span>${badge(t)}</div>
    ${t.status === 'resolved' && t.mine && !t.csat ? `<button class="ghost small" data-rate="${t.id}">Rate this support</button>` : ''}
    ${t.csat ? `<span class="hint">Rating: ${'★'.repeat(t.csat)}</span>` : ''}</div>`).join('') || '<p class="hint">No tickets yet.</p>';
  $('#mine-more').hidden = items.length >= total;
  if (session.user) $('#mine-more').textContent = `Load more (${total - items.length} left)`;
}
