import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { HttpError, listTickets, getTicket, createTicket, updateTicket, autoAssignNew, addReply, rateTicket, getAgentLoad, getStats } from './service.js';
import { verifyPassword, hashPassword, signToken, verifyToken, parseCookies, createLoginLimiter } from './auth.js';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const COOKIE = 'tt_session';
const SESSION_MS = 8 * 3600_000;
const DUMMY_HASH = hashPassword('not-a-real-password', { N: 1024 }); // keeps login timing similar for unknown users

export function createApp({ db, secret, now = Date.now, secureCookies = false }) {
  const app = express();
  const limiter = createLoginLimiter();
  app.disable('x-powered-by');

  app.use((req, res, next) => {
    res.setHeader('Content-Security-Policy', [
      "default-src 'self'", "script-src 'self' https://cdnjs.cloudflare.com", "style-src 'self' https://fonts.googleapis.com",
      "style-src-attr 'unsafe-inline'", "font-src https://fonts.gstatic.com", "img-src 'self' data:", "connect-src 'self'",
      "frame-ancestors 'none'", "base-uri 'self'", "form-action 'self'",
    ].join('; '));
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Cache-Control', req.path.startsWith('/api') ? 'no-store' : 'no-cache');
    next();
  });
  app.use(express.json({ limit: '20kb' }));

  // Mutating requests must be JSON; together with SameSite=Strict cookies this blocks cross-site form posts.
  app.use((req, res, next) => {
    const mutating = ['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method);
    if (mutating && !String(req.headers['content-type'] || '').startsWith('application/json')) return next(new HttpError(415, 'Send JSON.'));
    next();
  });

  // Identify the user from the signed cookie, then reload them from the database so role changes apply immediately.
  app.use((req, res, next) => {
    const payload = verifyToken(parseCookies(req.headers.cookie)[COOKIE], secret, now());
    req.user = payload ? db.prepare('SELECT id, username, display, role FROM users WHERE id = ?').get(payload.uid) ?? null : null;
    next();
  });
  const requireAuth = (req, res, next) => (req.user ? next() : next(new HttpError(401, 'Please sign in.')));
  const send = (handler, status = 200) => (req, res, next) => {
    try { res.status(status).json({ serverTime: now(), ...handler(req, res) }); } catch (err) { next(err); }
  };
  const publicUser = (u) => ({ id: u.id, username: u.username, display: u.display, role: u.role });

  app.get('/api/me', send((req) => ({ user: req.user ? publicUser(req.user) : null })));

  app.post('/api/login', send((req, res) => {
    const key = req.ip;
    if (limiter.isBlocked(key, now())) throw new HttpError(429, 'Too many attempts. Try again later.');
    const username = typeof req.body?.username === 'string' ? req.body.username.trim().toLowerCase() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    const valid = verifyPassword(password, user ? user.pass_hash : DUMMY_HASH) && Boolean(user);
    if (!valid) { limiter.fail(key, now()); throw new HttpError(401, 'Incorrect username or password.'); }
    limiter.clear(key);
    const token = signToken({ uid: user.id }, secret, { ttlMs: SESSION_MS, now: now() });
    res.setHeader('Set-Cookie', `${COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}${secureCookies ? '; Secure' : ''}`);
    return { user: publicUser(user) };
  }));

  app.post('/api/logout', send((req, res) => {
    res.setHeader('Set-Cookie', `${COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`);
    return {};
  }));

  app.get('/api/tickets', requireAuth, send((req) => listTickets(db, req.user, req.query, now())));
  app.post('/api/tickets', requireAuth, send((req) => createTicket(db, req.user, req.body, now()), 201));
  app.post('/api/tickets/auto-assign', requireAuth, send((req) => autoAssignNew(db, req.user, now())));
  app.get('/api/tickets/:id', requireAuth, send((req) => ({ ticket: getTicket(db, req.user, req.params.id, now()) })));
  app.patch('/api/tickets/:id', requireAuth, send((req) => ({ ticket: updateTicket(db, req.user, req.params.id, req.body, now()) })));
  app.post('/api/tickets/:id/replies', requireAuth, send((req) => ({ ticket: addReply(db, req.user, req.params.id, req.body?.text, now()) }), 201));
  app.post('/api/tickets/:id/csat', requireAuth, send((req) => ({ ticket: rateTicket(db, req.user, req.params.id, req.body?.rating, now()) })));
  app.get('/api/agents', requireAuth, send((req) => ({ agents: getAgentLoad(db, req.user, now()) })));
  app.get('/api/stats', requireAuth, send((req) => ({ stats: getStats(db, req.user, now()) })));
  app.use('/api', (req, res, next) => next(new HttpError(404, 'Not found.')));

  app.use('/shared', express.static(path.join(ROOT, 'shared')));
  app.use(express.static(path.join(ROOT, 'public')));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, details: err.details });
    if (err.status && err.status < 500) return res.status(err.status).json({ error: 'Invalid request.' });
    console.error(err);
    return res.status(500).json({ error: 'Something went wrong.' });
  });
  return app;
}
