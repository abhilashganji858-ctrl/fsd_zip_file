import { randomBytes, scryptSync, timingSafeEqual, createHmac } from 'node:crypto';

/** Password hashing with scrypt. Stored format: scrypt$N$salt$hash (base64). */
export function hashPassword(password, { N = 16384 } = {}) {
  const salt = randomBytes(16);
  const key = scryptSync(password, salt, 32, { N });
  return `scrypt$${N}$${salt.toString('base64')}$${key.toString('base64')}`;
}

export function verifyPassword(password, stored) {
  const [alg, n, salt, hash] = String(stored).split('$');
  if (alg !== 'scrypt' || !salt || !hash) return false;
  const expected = Buffer.from(hash, 'base64');
  const key = scryptSync(String(password), Buffer.from(salt, 'base64'), expected.length, { N: Number(n) });
  return timingSafeEqual(key, expected);
}

/** Signed, expiring session token: base64url(payload).base64url(hmac-sha256). */
export function signToken(payload, secret, { ttlMs = 8 * 3600_000, now = Date.now() } = {}) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: now + ttlMs })).toString('base64url');
  const sig = createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}

export function verifyToken(token, secret, now = Date.now()) {
  if (typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expected = createHmac('sha256', secret).update(body).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    return payload.exp > now ? payload : null;
  } catch {
    return null;
  }
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/** In-memory brute-force guard: blocks a key after `max` failures inside `windowMs`. */
export function createLoginLimiter({ max = 10, windowMs = 15 * 60_000 } = {}) {
  const hits = new Map();
  const live = (key, now) => {
    const h = hits.get(key);
    if (h && now - h.first > windowMs) hits.delete(key);
    return hits.get(key);
  };
  return {
    isBlocked: (key, now = Date.now()) => (live(key, now)?.count ?? 0) >= max,
    fail(key, now = Date.now()) {
      const h = live(key, now) ?? { first: now, count: 0 };
      h.count++;
      hits.set(key, h);
    },
    clear: (key) => hits.delete(key),
  };
}
