import { DatabaseSync } from 'node:sqlite';
import { hashPassword } from './auth.js';
import { MINUTE } from '../shared/sla.js';

export const DEMO_PASSWORD = 'TicketTamer!23'; // demo accounts only

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  display TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer','agent','manager')),
  pass_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject TEXT NOT NULL,
  cat TEXT NOT NULL,
  pri TEXT NOT NULL,
  descr TEXT NOT NULL,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'new',
  agent_id INTEGER REFERENCES users(id),
  created INTEGER NOT NULL,
  first_response INTEGER,
  resolved INTEGER,
  notes TEXT NOT NULL DEFAULT '',
  csat INTEGER CHECK (csat BETWEEN 1 AND 5),
  breached_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets (status, created);
CREATE INDEX IF NOT EXISTS idx_tickets_customer ON tickets (customer_id);
CREATE INDEX IF NOT EXISTS idx_tickets_agent ON tickets (agent_id);
CREATE TABLE IF NOT EXISTS replies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  author_id INTEGER NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created INTEGER NOT NULL
);`;

export function openDb(file = ':memory:') {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  return db;
}

const CUSTOMERS = [['dana', 'Dana Whitfield'], ['omar', 'Omar Haddad'], ['lena', 'Lena Fischer'], ['ravi', 'Ravi Menon'], ['chloe', 'Chloe Park']];
const AGENTS = [['asha', 'Asha Rao'], ['marcus', 'Marcus Lee'], ['priya', 'Priya Nair'], ['tomas', 'Tomás Ruiz'], ['jun', 'Jun Park']];

// subject, category, priority, age (min), status, agent index, first response (min), resolution time (min)
const SEED_TICKETS = [
  ['Payment gateway crash on checkout', 'Technical', 'Urgent', 95, 'progress', 0, 8],
  ['Payment failed for annual plan', 'Billing', 'Urgent', 140, 'new', -1],
  ['Cannot login after password reset', 'Account', 'High', 200, 'progress', 1, 15],
  ['Invoice shows duplicate charge', 'Billing', 'High', 300, 'awaiting', 2, 22],
  ['Dashboard export is slow', 'Technical', 'Normal', 420, 'progress', 3, 40],
  ['Add dark mode to mobile app', 'Feature Request', 'Low', 900, 'new', -1],
  ['Update billing email address', 'Billing', 'Normal', 120, 'new', -1],
  ['API returns 500 intermittently', 'Technical', 'High', 60, 'new', -1],
  ['Merge two accounts', 'Account', 'Normal', 600, 'awaiting', 4, 35],
  ['Refund for cancelled seat', 'Billing', 'High', 180, 'progress', 2, 12],
  ['SSO setup guidance', 'Account', 'Normal', 1300, 'progress', 1, 55],
  ['Webhook listener timing out', 'Technical', 'Urgent', 40, 'new', -1],
  ['Request CSV import for contacts', 'Feature Request', 'Low', 2000, 'new', -1],
  ['Tax ID missing from invoice', 'Billing', 'Normal', 800, 'resolved', 0, 25, 300],
  ['Two-factor code not arriving', 'Account', 'High', 500, 'resolved', 3, 18, 200],
  ['App crash when uploading files', 'Technical', 'Urgent', 700, 'resolved', 4, 10, 170],
  ['Change plan mid-cycle', 'Billing', 'Normal', 1100, 'resolved', 1, 30, 500],
  ['Slack integration request', 'Feature Request', 'Low', 2500, 'resolved', 2, 90, 1500],
  ['Cannot login on mobile', 'Account', 'High', 1000, 'resolved', 0, 14, 210],
  ['Charge appears after cancellation', 'Billing', 'High', 360, 'resolved', 3, 20, 150],
];

/** Fills an empty database with demo users and 20 tickets. Does nothing if users already exist. */
export function seedIfEmpty(db, { now = Date.now(), scryptN } = {}) {
  if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) return false;
  const addUser = db.prepare('INSERT INTO users (username, display, role, pass_hash) VALUES (?, ?, ?, ?)');
  const hash = () => hashPassword(DEMO_PASSWORD, scryptN ? { N: scryptN } : undefined);
  const id = (u) => Number(addUser.run(u[0], u[1], u[2], hash()).lastInsertRowid);
  const customerIds = CUSTOMERS.map(([u, d]) => id([u, d, 'customer']));
  const agentIds = AGENTS.map(([u, d]) => id([u, d, 'agent']));
  id(['manager', 'Morgan Blake', 'manager']);

  const add = db.prepare(`INSERT INTO tickets (subject, cat, pri, descr, customer_id, status, agent_id, created, first_response, resolved)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  SEED_TICKETS.forEach(([subject, cat, pri, age, status, agent, frt, res], i) => {
    const created = now - age * MINUTE;
    add.run(subject, cat, pri, `Customer report: ${subject}. Please advise.`, customerIds[i % customerIds.length], status,
      agent >= 0 ? agentIds[agent] : null, created, frt != null ? created + frt * MINUTE : null, res ? created + res * MINUTE : null);
  });
  return true;
}
