import fs from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openDb, seedIfEmpty, DEMO_PASSWORD } from './db.js';
import { createApp } from './app.js';
import { scanBreaches } from './service.js';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = process.env.DB_FILE || path.join(ROOT, 'data', 'tickettamer.db');
fs.mkdirSync(path.dirname(file), { recursive: true });

const db = openDb(file);
if (seedIfEmpty(db)) console.log(`Seeded demo data. Demo password for every account: ${DEMO_PASSWORD}`);

let secret = process.env.SESSION_SECRET;
if (!secret) {
  secret = randomBytes(32).toString('hex');
  console.warn('SESSION_SECRET is not set: using a random one, so sign-ins reset on every restart.');
}

const app = createApp({ db, secret, secureCookies: process.env.NODE_ENV === 'production' });
const port = Number(process.env.PORT) || 3000;
app.listen(port, () => console.log(`TicketTamer running at http://localhost:${port}`));

// Escalation timer: every 30 seconds record tickets that have just breached their SLA.
setInterval(() => {
  const ids = scanBreaches(db);
  if (ids.length) console.log(`SLA breached: ticket ${ids.join(', ')}`);
}, 30_000);
