import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
for (const f of ['tickettamer.db', 'tickettamer.db-wal', 'tickettamer.db-shm']) fs.rmSync(path.join(dir, f), { force: true });
console.log('Database deleted. It will be recreated with demo data on the next start.');
