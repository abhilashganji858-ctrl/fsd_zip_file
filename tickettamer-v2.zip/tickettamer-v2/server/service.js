// Business logic. Pure functions of (db, viewer, input, now) so they can be unit-tested without HTTP.
import { MINUTE, SLA_MINUTES, STATUSES, TRANSITIONS, autoPriority, dueAt, isBreached, slaState } from '../shared/sla.js';
import { LIMITS, cleanText, validateTicketInput } from '../shared/sanitize.js';
import { computeStats } from '../shared/stats.js';

export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}
const fail = (status, message, details) => { throw new HttpError(status, message, details); };
const isStaff = (viewer) => viewer.role === 'agent' || viewer.role === 'manager';
const requireStaff = (viewer) => { if (!isStaff(viewer)) fail(403, 'Support staff only.'); };

const DUE_SQL = `(created + CASE pri ${Object.entries(SLA_MINUTES).map(([p, m]) => `WHEN '${p}' THEN ${m * MINUTE}`).join(' ')} END)`;

const toTicket = (r) => r && ({
  id: r.id, subject: r.subject, cat: r.cat, pri: r.pri, desc: r.descr, customerId: r.customer_id, status: r.status,
  agentId: r.agent_id, created: r.created, firstResponse: r.first_response, resolved: r.resolved, notes: r.notes,
  csat: r.csat, breachedAt: r.breached_at,
});

const usersById = (db) => new Map(db.prepare('SELECT id, username, display, role FROM users').all().map((u) => [u.id, u]));

function toDto(t, users, viewer, now) {
  const agent = t.agentId ? users.get(t.agentId) : null;
  return {
    id: t.id, subject: t.subject, cat: t.cat, pri: t.pri, desc: t.desc, status: t.status, created: t.created,
    firstResponse: t.firstResponse, resolved: t.resolved, csat: t.csat, dueAt: dueAt(t),
    customer: users.get(t.customerId)?.display ?? 'Unknown', mine: t.customerId === viewer.id,
    agent: agent ? { username: agent.username, display: agent.display } : null,
    notes: isStaff(viewer) ? t.notes : undefined, // resolution notes are internal
    sla: slaState(t, now),
  };
}

function loadTicket(db, id) {
  const row = db.prepare('SELECT * FROM tickets WHERE id = ?').get(Number(id));
  if (!row) fail(404, 'Ticket not found.');
  return toTicket(row);
}

const clampInt = (v, min, max, fallback) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

/** Paginated list. Customers only ever see their own tickets. */
export function listTickets(db, viewer, { status, page, pageSize } = {}, now = Date.now()) {
  const where = [];
  const args = [];
  if (viewer.role === 'customer') { where.push('customer_id = ?'); args.push(viewer.id); }
  if (status) {
    if (!STATUSES.includes(status)) fail(400, 'Unknown status.');
    where.push('status = ?'); args.push(status);
  }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const size = clampInt(pageSize, 1, 50, 10);
  const pg = clampInt(page, 1, 100000, 1);
  const order = status === 'resolved' ? 'resolved DESC' : status ? `${DUE_SQL} ASC` : 'created DESC';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM tickets ${clause}`).get(...args).n;
  const rows = db.prepare(`SELECT * FROM tickets ${clause} ORDER BY ${order}, id DESC LIMIT ? OFFSET ?`).all(...args, size, (pg - 1) * size);
  const users = usersById(db);
  return { items: rows.map((r) => toDto(toTicket(r), users, viewer, now)), total, page: pg, pageSize: size };
}

export function getTicket(db, viewer, id, now = Date.now()) {
  const t = loadTicket(db, id);
  if (viewer.role === 'customer' && t.customerId !== viewer.id) fail(404, 'Ticket not found.');
  const users = usersById(db);
  const replies = db.prepare('SELECT * FROM replies WHERE ticket_id = ? ORDER BY created, id').all(t.id)
    .map((r) => ({ id: r.id, author: users.get(r.author_id)?.display ?? 'Unknown', body: r.body, created: r.created }));
  return { ...toDto(t, users, viewer, now), replies };
}

export function createTicket(db, viewer, body, now = Date.now()) {
  const { ok, errors, value } = validateTicketInput(body);
  if (!ok) fail(400, 'Please fix the highlighted fields.', errors);
  const pri = autoPriority(value.subject, value.pri);
  const res = db.prepare('INSERT INTO tickets (subject, cat, pri, descr, customer_id, created) VALUES (?, ?, ?, ?, ?, ?)')
    .run(value.subject, value.cat, pri, value.desc, viewer.id, now);
  return { ticket: getTicket(db, viewer, Number(res.lastInsertRowid), now), priorityRaised: pri !== value.pri };
}

function leastLoadedAgentId(db) {
  return db.prepare(`SELECT u.id FROM users u LEFT JOIN tickets t ON t.agent_id = u.id AND t.status != 'resolved'
                     WHERE u.role = 'agent' GROUP BY u.id ORDER BY COUNT(t.id), u.id LIMIT 1`).get()?.id ?? null;
}

/** Staff update: status (validated against the state machine), agent assignment and internal notes. */
export function updateTicket(db, viewer, id, patch = {}, now = Date.now()) {
  requireStaff(viewer);
  const t = loadTicket(db, id);
  const set = {};

  if ('notes' in patch) set.notes = cleanText(patch.notes, { max: LIMITS.notes, multiline: true });

  if ('agent' in patch) {
    if (patch.agent === null || patch.agent === '') {
      if (viewer.role === 'agent' && t.agentId !== null && t.agentId !== viewer.id) fail(403, 'Agents can only unassign their own tickets.');
      set.agent_id = null;
    } else {
      const agent = db.prepare("SELECT id FROM users WHERE username = ? AND role = 'agent'").get(String(patch.agent));
      if (!agent) fail(400, 'Unknown agent.');
      if (viewer.role === 'agent' && agent.id !== viewer.id) fail(403, 'Agents can only assign tickets to themselves.');
      set.agent_id = agent.id;
    }
  }

  if ('status' in patch && patch.status !== t.status) {
    if (!STATUSES.includes(patch.status)) fail(400, 'Unknown status.');
    if (!TRANSITIONS[t.status].includes(patch.status)) fail(409, `A ticket cannot move from "${t.status}" to "${patch.status}".`);
    set.status = patch.status;
    if (t.firstResponse == null && patch.status !== 'new') set.first_response = now;
    const agentAfter = 'agent_id' in set ? set.agent_id : t.agentId;
    if (patch.status === 'progress' && agentAfter == null) set.agent_id = viewer.role === 'agent' ? viewer.id : leastLoadedAgentId(db);
    set.resolved = patch.status === 'resolved' ? now : null;
  }

  const keys = Object.keys(set); // keys are internal constants, never user input
  if (keys.length) db.prepare(`UPDATE tickets SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`).run(...keys.map((k) => set[k]), t.id);
  return getTicket(db, viewer, t.id, now);
}

/** Manager action: give every unassigned new ticket to the least-loaded agent and start work. */
export function autoAssignNew(db, viewer, now = Date.now()) {
  if (viewer.role !== 'manager') fail(403, 'Managers only.');
  const rows = db.prepare("SELECT id FROM tickets WHERE status = 'new' AND agent_id IS NULL ORDER BY created").all();
  const update = db.prepare("UPDATE tickets SET agent_id = ?, status = 'progress', first_response = COALESCE(first_response, ?) WHERE id = ?");
  for (const { id } of rows) update.run(leastLoadedAgentId(db), now, id);
  return { assigned: rows.length };
}

export function addReply(db, viewer, id, body, now = Date.now()) {
  requireStaff(viewer);
  const t = loadTicket(db, id);
  const text = cleanText(body, { max: LIMITS.reply, multiline: true });
  if (!text) fail(400, 'Reply cannot be empty.');
  db.prepare('INSERT INTO replies (ticket_id, author_id, body, created) VALUES (?, ?, ?, ?)').run(t.id, viewer.id, text, now);
  if (t.firstResponse == null) db.prepare('UPDATE tickets SET first_response = ? WHERE id = ?').run(now, t.id);
  return getTicket(db, viewer, t.id, now);
}

export function rateTicket(db, viewer, id, rating, now = Date.now()) {
  const t = loadTicket(db, id);
  if (t.customerId !== viewer.id) fail(404, 'Ticket not found.');
  if (t.status !== 'resolved') fail(409, 'Only resolved tickets can be rated.');
  if (t.csat != null) fail(409, 'This ticket has already been rated.');
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) fail(400, 'Rating must be a whole number from 1 to 5.');
  db.prepare('UPDATE tickets SET csat = ? WHERE id = ?').run(rating, t.id);
  return getTicket(db, viewer, t.id, now);
}

/** Escalation timer: records the moment an open ticket first crossed its deadline. Returns the newly breached ids. */
export function scanBreaches(db, now = Date.now()) {
  const open = db.prepare("SELECT * FROM tickets WHERE status != 'resolved' AND breached_at IS NULL").all().map(toTicket);
  const hit = open.filter((t) => isBreached(t, now));
  const mark = db.prepare('UPDATE tickets SET breached_at = ? WHERE id = ?');
  hit.forEach((t) => mark.run(dueAt(t), t.id));
  return hit.map((t) => t.id);
}

export function getAgentLoad(db, viewer, now = Date.now()) {
  requireStaff(viewer);
  const open = db.prepare("SELECT * FROM tickets WHERE status != 'resolved' AND agent_id IS NOT NULL").all().map(toTicket);
  return db.prepare("SELECT id, username, display FROM users WHERE role = 'agent' ORDER BY id").all().map((a) => {
    const mine = open.filter((t) => t.agentId === a.id);
    return { username: a.username, display: a.display, open: mine.length, breached: mine.filter((t) => isBreached(t, now)).length };
  });
}

export function getStats(db, viewer, now = Date.now()) {
  requireStaff(viewer);
  const tickets = db.prepare('SELECT * FROM tickets').all().map(toTicket);
  const agents = db.prepare("SELECT id, display FROM users WHERE role = 'agent' ORDER BY id").all();
  return computeStats(tickets, agents, now);
}
