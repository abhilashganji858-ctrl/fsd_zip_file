export const CANNED = Object.freeze({
  'Billing: duplicate charge': 'Thanks for flagging this. We found the duplicate charge and have started a refund; it appears in 3-5 business days.',
  'Billing: invoice copy': 'Your updated invoice is attached. Reply if any detail still looks wrong.',
  'Technical: restart steps': 'Please sign out, clear the app cache, and restart. If the issue continues, send us the time it occurred.',
  'Technical: patch deployed': 'A fix is now live. Please retry and let us know if you still see the error.',
  'Account: reset link': 'We sent a fresh password reset link. It expires in 30 minutes.',
});
