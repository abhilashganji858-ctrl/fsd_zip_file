import { CATEGORIES, PRIORITIES } from './sla.js';

export const LIMITS = Object.freeze({ subject: 120, desc: 2000, reply: 1000, notes: 500 });

export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/**
 * Normalizes user text: removes control characters and HTML tags, collapses whitespace
 * and enforces a maximum length. Non-strings become an empty string.
 */
export function cleanText(value, { max = 255, multiline = false } = {}) {
  if (typeof value !== 'string') return '';
  let s = value.normalize('NFC').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
  s = s.replace(/<[^>]*>/g, '').replace(/[<>]/g, '');
  s = multiline
    ? s.replace(/\r\n?/g, '\n').replace(/[ \t]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim()
    : s.replace(/\s+/g, ' ').trim();
  return s.slice(0, max);
}

/** Validates and cleans a new-ticket payload. Used by the form (browser) and the API (server). */
export function validateTicketInput(body) {
  const errors = {};
  const subject = cleanText(body?.subject, { max: LIMITS.subject });
  const desc = cleanText(body?.desc, { max: LIMITS.desc, multiline: true });
  if (subject.length < 3) errors.subject = 'Subject must be at least 3 characters.';
  if (!CATEGORIES.includes(body?.cat)) errors.cat = 'Choose a valid category.';
  if (!PRIORITIES.includes(body?.pri)) errors.pri = 'Choose a valid priority.';
  if (desc.length < 10) errors.desc = 'Describe the issue in at least 10 characters.';
  return { ok: Object.keys(errors).length === 0, errors, value: { subject, cat: body?.cat, pri: body?.pri, desc } };
}
