// Single source of truth for SLA rules. Imported by the server, the browser and the tests.
export const MINUTE = 60_000;
export const SLA_MINUTES = Object.freeze({ Urgent: 120, High: 240, Normal: 1440, Low: 2880 });
export const PRIORITIES = Object.freeze(Object.keys(SLA_MINUTES));
export const CATEGORIES = Object.freeze(['Billing', 'Technical', 'Account', 'Feature Request']);
export const STATUSES = Object.freeze(['new', 'progress', 'awaiting', 'resolved']);
export const STATUS_LABELS = Object.freeze({
  new: 'New / Unassigned', progress: 'In Progress', awaiting: 'Awaiting Customer', resolved: 'Resolved',
});

/** Ticket lifecycle state machine: which stages a ticket may move to from each stage. */
export const TRANSITIONS = Object.freeze({
  new: ['progress', 'awaiting', 'resolved'],
  progress: ['new', 'awaiting', 'resolved'],
  awaiting: ['progress', 'resolved'],
  resolved: ['progress'], // reopen
});

const RANK = { Low: 0, Normal: 1, High: 2, Urgent: 3 };
const KEYWORD_RULES = [
  { re: /crash|outage|data loss|payment failed/i, priority: 'Urgent' },
  { re: /cannot log ?in|can.?t log ?in|locked out|refund/i, priority: 'High' },
];

/** Raises priority when the subject matches a keyword rule. Never lowers it. */
export function autoPriority(subject, current = 'Normal') {
  let result = PRIORITIES.includes(current) ? current : 'Normal';
  for (const { re, priority } of KEYWORD_RULES) {
    if (re.test(String(subject)) && RANK[priority] > RANK[result]) result = priority;
  }
  return result;
}

export const dueAt = (t) => t.created + SLA_MINUTES[t.pri] * MINUTE;
export const isBreached = (t, now) => t.resolved == null && now > dueAt(t);

export function formatDuration(ms) {
  const m = Math.floor(Math.max(0, ms) / MINUTE);
  const h = Math.floor(m / 60);
  return h ? `${h}h ${String(m % 60).padStart(2, '0')}m` : `${m}m`;
}

/**
 * SLA state of a ticket at time `now`.
 * ok = safe (at least half the window left), warn = under half left, bad = breached.
 * A ticket resolved exactly at its deadline counts as on time.
 */
export function slaState(t, now) {
  const due = dueAt(t);
  if (t.resolved != null) {
    const late = t.resolved > due;
    return { state: late ? 'bad' : 'ok', remainingMs: due - t.resolved, final: true, label: late ? 'Resolved late' : 'Resolved on time' };
  }
  const remaining = due - now;
  const window = SLA_MINUTES[t.pri] * MINUTE;
  if (remaining < 0) return { state: 'bad', remainingMs: remaining, final: false, label: `Breached ${formatDuration(-remaining)} ago` };
  return { state: remaining < window / 2 ? 'warn' : 'ok', remainingMs: remaining, final: false, label: `${formatDuration(remaining)} SLA remaining` };
}
