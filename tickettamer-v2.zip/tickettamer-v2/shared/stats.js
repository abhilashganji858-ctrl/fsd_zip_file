import { MINUTE, isBreached, slaState, CATEGORIES } from './sla.js';

/**
 * Builds the analytics payload.
 * tickets: [{ id, cat, pri, created, firstResponse, resolved, agentId }]
 * agents:  [{ id, display }]
 * Compliance = on-time resolutions / (resolved + open breaches). null when there is no data yet.
 */
export function computeStats(tickets, agents, now) {
  const resolved = tickets.filter((t) => t.resolved != null);
  const onTime = resolved.filter((t) => slaState(t, now).state === 'ok');
  const openBreaches = tickets.filter((t) => isBreached(t, now));
  const denominator = resolved.length + openBreaches.length;
  const responded = tickets.filter((t) => t.firstResponse != null);

  const byCategory = Object.fromEntries(CATEGORIES.map((c) => [c, tickets.filter((t) => t.cat === c).length]));
  const hourly = Array(24).fill(0); // index 23 = the most recent hour
  for (const t of tickets) {
    const age = Math.floor((now - t.created) / (60 * MINUTE));
    if (age >= 0 && age < 24) hourly[23 - age]++;
  }

  const agentRows = agents.map((a) => {
    const mine = tickets.filter((t) => t.agentId === a.id);
    const done = mine.filter((t) => t.resolved != null);
    const ok = done.filter((t) => slaState(t, now).state === 'ok').length;
    const avgHours = done.length ? done.reduce((s, t) => s + (t.resolved - t.created), 0) / done.length / MINUTE / 60 : 0;
    return {
      id: a.id, name: a.display, open: mine.length - done.length, resolved: done.length, onTime: ok,
      avgHours: Math.round(avgHours * 10) / 10, index: Math.round((ok * 10) / (1 + avgHours)),
    };
  });

  return {
    total: tickets.length,
    slaCompliancePct: denominator ? Math.round((100 * onTime.length) / denominator) : null,
    meanResponseMin: responded.length ? Math.round(responded.reduce((s, t) => s + (t.firstResponse - t.created), 0) / responded.length / MINUTE) : null,
    openBreaches: openBreaches.length,
    byCategory, hourly, agents: agentRows,
  };
}
