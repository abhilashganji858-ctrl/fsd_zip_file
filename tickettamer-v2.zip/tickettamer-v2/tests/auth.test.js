import test from 'node:test';
import assert from 'node:assert/strict';
import { createLoginLimiter, hashPassword, parseCookies, signToken, verifyPassword, verifyToken } from '../server/auth.js';

test('password hashes verify and are salted', () => {
  const a = hashPassword('s3cret!', { N: 1024 });
  const b = hashPassword('s3cret!', { N: 1024 });
  assert.notEqual(a, b);
  assert.equal(verifyPassword('s3cret!', a), true);
  assert.equal(verifyPassword('wrong', a), false);
  assert.equal(verifyPassword('s3cret!', 'garbage'), false);
});

test('tokens verify, expire and reject tampering', () => {
  const now = 1_000_000;
  const token = signToken({ uid: 7 }, 'k1', { ttlMs: 1000, now });
  assert.equal(verifyToken(token, 'k1', now + 500).uid, 7);
  assert.equal(verifyToken(token, 'k1', now + 1500), null);
  assert.equal(verifyToken(token, 'other-key', now), null);
  const [body, sig] = token.split('.');
  const forged = Buffer.from(JSON.stringify({ uid: 1, exp: now + 99999 })).toString('base64url');
  assert.equal(verifyToken(`${forged}.${sig}`, 'k1', now), null);
  assert.equal(verifyToken(undefined, 'k1', now), null);
  assert.equal(verifyToken(`${body}`, 'k1', now), null);
});

test('parseCookies', () => {
  assert.deepEqual(parseCookies('a=1; tt_session=abc.def; b=x%20y'), { a: '1', tt_session: 'abc.def', b: 'x y' });
  assert.deepEqual(parseCookies(undefined), {});
});

test('login limiter blocks after repeated failures and resets after the window', () => {
  const l = createLoginLimiter({ max: 3, windowMs: 1000 });
  for (let i = 0; i < 3; i++) l.fail('ip', 0);
  assert.equal(l.isBlocked('ip', 500), true);
  assert.equal(l.isBlocked('ip', 2000), false);
  l.fail('ip2', 0); l.clear('ip2');
  assert.equal(l.isBlocked('ip2', 1), false);
});
