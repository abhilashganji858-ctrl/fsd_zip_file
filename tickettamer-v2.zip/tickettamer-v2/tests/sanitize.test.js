import test from 'node:test';
import assert from 'node:assert/strict';
import { LIMITS, cleanText, escapeHtml, validateTicketInput } from '../shared/sanitize.js';

test('cleanText strips tags and control characters', () => {
  assert.equal(cleanText('<script>alert(1)</script>Hello'), 'alert(1)Hello');
  assert.equal(cleanText('a\u0000b\u0007c'), 'abc');
  assert.equal(cleanText('5 < 7'), '5 7'); // stray angle brackets are dropped
  assert.equal(cleanText('<img src=x onerror=alert(1)>Hi'), 'Hi');
});

test('cleanText collapses whitespace, caps length and rejects non-strings', () => {
  assert.equal(cleanText('  a   b \n c '), 'a b c');
  assert.equal(cleanText('x'.repeat(500), { max: 10 }).length, 10);
  assert.equal(cleanText(42), '');
  assert.equal(cleanText(null), '');
});

test('cleanText keeps paragraphs in multiline mode', () => {
  assert.equal(cleanText('line 1  \r\n\r\n\r\n\r\nline 2', { multiline: true }), 'line 1\n\nline 2');
});

test('escapeHtml escapes quotes and angle brackets', () => {
  assert.equal(escapeHtml(`<a href="x">'&'</a>`), '&lt;a href=&quot;x&quot;&gt;&#39;&amp;&#39;&lt;/a&gt;');
  assert.equal(escapeHtml(undefined), '');
});

test('validateTicketInput accepts a good ticket and cleans it', () => {
  const r = validateTicketInput({ subject: '  <b>Payment</b> crash ', cat: 'Technical', pri: 'Normal', desc: 'Checkout fails with a 500 error.' });
  assert.equal(r.ok, true);
  assert.equal(r.value.subject, 'Payment crash');
});

test('validateTicketInput reports every bad field', () => {
  const r = validateTicketInput({ subject: 'ab', cat: 'Sales', pri: 'Critical', desc: 'short' });
  assert.equal(r.ok, false);
  assert.deepEqual(Object.keys(r.errors).sort(), ['cat', 'desc', 'pri', 'subject']);
  assert.equal(validateTicketInput(undefined).ok, false);
});

test('validateTicketInput enforces the subject limit', () => {
  const r = validateTicketInput({ subject: 'x'.repeat(500), cat: 'Billing', pri: 'Low', desc: 'long enough description' });
  assert.equal(r.value.subject.length, LIMITS.subject);
});
