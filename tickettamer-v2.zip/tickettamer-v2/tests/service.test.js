import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb, seedIfEmpty } from '../server/db.js';
import { HttpError, addReply, autoAssignNew, createTicket, getAgentLoad, getStats, getTicket, listTickets, rateTicket, scanBreaches, updateTicket } from '../server/service.js';
import { MINUTE } from '../shared/sla.js';

const now = 1_700_000_000_000;
function setup() {
  const db = openDb(':memory:');
  seedIfEmpty(db, { now, scryptN: 1024 });
  const who = (u) => db.prepare('SELECT id, username, display, role FROM users WHERE username = ?').get(u);
  return { db, dana: who('dana'), asha: who('asha'), marcus: who('marcus'), manager: who('manager') };
}
const rejects = (fn, status) => assert.throws(fn, (e) => e instanceof HttpError && e.status === status);
const goodBody = { subject: 'Cannot login to the portal', cat: 'Account', pri: 'Normal', desc: 'The login page keeps failing for me.' };

test('seed data: 20 tickets across all four stages', () => {
  const { db, manager } = setup();
  assert.equal(listTickets(db, manager, {}, now).total, 20);
  for (const status of ['new', 'progress', 'awaiting', 'resolved']) assert.ok(listTickets(db, manager, { status }, now).total > 0);
});

test('pagination returns pages without overlap and clamps page size', () => {
  const { db, manager } = setup();
  const p1 = listTickets(db, manager, { page: 1, pageSize: 8 }, now);
  const p2 = listTickets(db, manager, { page: 2, pageSize: 8 }, now);
  assert.equal(p1.items.length, 8);
  assert.equal(p2.items.length, 8);
  assert.equal(new Set([...p1.items, ...p2.items].map((t) => t.id)).size, 16);
  assert.equal(listTickets(db, manager, { pageSize: 9999 }, now).pageSize, 50);
  assert.equal(listTickets(db, manager, { page: -3, pageSize: 'x' }, now).page, 1);
  rejects(() => listTickets(db, manager, { status: 'bogus' }, now), 400);
});

test('board columns are ordered by closest SLA deadline', () => {
  const { db, manager } = setup();
  const due = listTickets(db, manager, { status: 'new' }, now).items.map((t) => t.dueAt);
  assert.deepEqual(due, [...due].sort((a, b) => a - b));
});

test('customers only see their own tickets', () => {
  const { db, dana, manager } = setup();
  const mine = listTickets(db, dana, {}, now);
  assert.equal(mine.total, 4);
  assert.ok(mine.items.every((t) => t.mine));
  assert.equal(mine.items[0].notes, undefined);
  const others = listTickets(db, manager, {}, now).items.find((t) => !t.mine);
  rejects(() => getTicket(db, dana, others.id, now), 404);
});

test('creating a ticket sanitizes input and raises priority from keywords', () => {
  const { db, dana } = setup();
  const r = createTicket(db, dana, { ...goodBody, subject: '<b>Payment</b> Gateway Crash', pri: 'Normal' }, now);
  assert.equal(r.ticket.subject, 'Payment Gateway Crash');
  assert.equal(r.ticket.pri, 'Urgent');
  assert.equal(r.priorityRaised, true);
  assert.equal(r.ticket.sla.label, '2h 00m SLA remaining');
  assert.equal(r.ticket.status, 'new');
  assert.equal(createTicket(db, dana, { ...goodBody, subject: 'Question about plans' }, now).priorityRaised, false);
});

test('invalid tickets are rejected with field errors', () => {
  const { db, dana } = setup();
  assert.throws(() => createTicket(db, dana, { subject: '', cat: 'x' }, now), (e) => e.status === 400 && 'subject' in e.details && 'cat' in e.details);
});

test('customers cannot update tickets', () => {
  const { db, dana } = setup();
  rejects(() => updateTicket(db, dana, 1, { status: 'resolved' }, now), 403);
});

test('claiming a ticket assigns the agent and logs first response', () => {
  const { db, asha } = setup();
  const newTicket = listTickets(db, asha, { status: 'new' }, now).items[0];
  const t = updateTicket(db, asha, newTicket.id, { status: 'progress' }, now + 5 * MINUTE);
  assert.equal(t.status, 'progress');
  assert.equal(t.agent.username, 'asha');
  assert.equal(t.firstResponse, now + 5 * MINUTE);
});

test('state machine rejects illegal moves; resolving and reopening work', () => {
  const { db, asha } = setup();
  const id = listTickets(db, asha, { status: 'new' }, now).items[0].id;
  updateTicket(db, asha, id, { status: 'progress' }, now);
  const resolved = updateTicket(db, asha, id, { status: 'resolved', notes: '<i>Patched webhook listener</i>' }, now + MINUTE);
  assert.equal(resolved.resolved, now + MINUTE);
  assert.equal(resolved.notes, 'Patched webhook listener');
  rejects(() => updateTicket(db, asha, id, { status: 'awaiting' }, now), 409);
  rejects(() => updateTicket(db, asha, id, { status: 'banana' }, now), 400);
  assert.equal(updateTicket(db, asha, id, { status: 'progress' }, now + 2 * MINUTE).resolved, null);
});

test('agents may only assign tickets to themselves; managers may assign anyone', () => {
  const { db, asha, manager } = setup();
  const id = listTickets(db, asha, { status: 'new' }, now).items[0].id;
  rejects(() => updateTicket(db, asha, id, { agent: 'marcus' }, now), 403);
  assert.equal(updateTicket(db, manager, id, { agent: 'marcus' }, now).agent.username, 'marcus');
  rejects(() => updateTicket(db, asha, id, { agent: null }, now), 403);
  rejects(() => updateTicket(db, manager, id, { agent: 'dana' }, now), 400);
  assert.equal(updateTicket(db, manager, id, { agent: null }, now).agent, null);
});

test('auto-assign gives new tickets to the least-loaded agents (managers only)', () => {
  const { db, asha, manager } = setup();
  rejects(() => autoAssignNew(db, asha, now), 403);
  const before = listTickets(db, manager, { status: 'new' }, now).total;
  assert.equal(autoAssignNew(db, manager, now).assigned, before);
  assert.equal(listTickets(db, manager, { status: 'new' }, now).total, 0);
  const load = getAgentLoad(db, manager, now).map((a) => a.open);
  assert.ok(Math.max(...load) - Math.min(...load) <= 1, `uneven load: ${load}`);
});

test('replies are sanitized, staff-only and set first response once', () => {
  const { db, dana, asha } = setup();
  const id = listTickets(db, asha, { status: 'new' }, now).items[0].id;
  rejects(() => addReply(db, dana, id, 'hi', now), 403);
  rejects(() => addReply(db, asha, id, '   ', now), 400);
  const t = addReply(db, asha, id, '<script>x</script>We are on it.', now + MINUTE);
  assert.equal(t.replies[0].body, 'xWe are on it.');
  assert.equal(t.firstResponse, now + MINUTE);
  assert.equal(addReply(db, asha, id, 'Update', now + 9 * MINUTE).firstResponse, now + MINUTE);
});

test('CSAT: owner only, resolved only, once, 1 to 5', () => {
  const { db, dana, asha } = setup();
  const resolved = listTickets(db, dana, { status: 'resolved' }, now).items[0];
  const open = listTickets(db, dana, { status: 'new' }, now).items[0] ?? listTickets(db, dana, { status: 'progress' }, now).items[0];
  rejects(() => rateTicket(db, dana, open.id, 5, now), 409);
  rejects(() => rateTicket(db, asha, resolved.id, 5, now), 404);
  rejects(() => rateTicket(db, dana, resolved.id, 6, now), 400);
  rejects(() => rateTicket(db, dana, resolved.id, 4.5, now), 400);
  assert.equal(rateTicket(db, dana, resolved.id, 5, now).csat, 5);
  rejects(() => rateTicket(db, dana, resolved.id, 3, now), 409);
});

test('escalation scan marks each breach once', () => {
  const { db } = setup();
  const first = scanBreaches(db, now);
  assert.ok(first.length > 0);
  assert.deepEqual(scanBreaches(db, now), []);
  const next = scanBreaches(db, now + 3 * 24 * 60 * MINUTE);
  assert.ok(next.length > 0);
});

test('stats are staff-only and cover all tickets', () => {
  const { db, dana, manager } = setup();
  rejects(() => getStats(db, dana, now), 403);
  const s = getStats(db, manager, now);
  assert.equal(s.total, 20);
  assert.equal(s.agents.length, 5);
  assert.equal(Object.values(s.byCategory).reduce((a, b) => a + b, 0), 20);
});
