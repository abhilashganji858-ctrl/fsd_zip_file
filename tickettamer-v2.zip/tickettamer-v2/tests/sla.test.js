import test from 'node:test';
import assert from 'node:assert/strict';
import { MINUTE, SLA_MINUTES, TRANSITIONS, autoPriority, dueAt, formatDuration, isBreached, slaState } from '../shared/sla.js';

const t0 = 1_700_000_000_000;
const ticket = (pri, extra = {}) => ({ pri, created: t0, resolved: null, ...extra });

test('SLA windows match the brief', () => {
  assert.deepEqual([SLA_MINUTES.Urgent, SLA_MINUTES.High, SLA_MINUTES.Normal], [120, 240, 1440]);
  assert.equal(dueAt(ticket('Urgent')), t0 + 2 * 60 * MINUTE);
});

test('open ticket: safe, then approaching, then breached', () => {
  const t = ticket('Urgent');
  assert.equal(slaState(t, t0 + 10 * MINUTE).state, 'ok');
  assert.equal(slaState(t, t0 + 60 * MINUTE).state, 'ok'); // exactly half left is still safe
  assert.equal(slaState(t, t0 + 61 * MINUTE).state, 'warn');
  assert.equal(slaState(t, t0 + 120 * MINUTE).state, 'warn'); // at the deadline, not yet breached
  const late = slaState(t, t0 + 121 * MINUTE);
  assert.equal(late.state, 'bad');
  assert.match(late.label, /^Breached 1m ago$/);
});

test('countdown label shows the time remaining', () => {
  assert.equal(slaState(ticket('Urgent'), t0 + 8 * MINUTE).label, '1h 52m SLA remaining');
});

test('resolved ticket: on time at the deadline, late one minute after', () => {
  assert.equal(slaState(ticket('High', { resolved: t0 + 240 * MINUTE }), t0 + 999 * MINUTE).state, 'ok');
  const late = slaState(ticket('High', { resolved: t0 + 241 * MINUTE }), t0 + 999 * MINUTE);
  assert.equal(late.state, 'bad');
  assert.equal(late.label, 'Resolved late');
});

test('isBreached ignores resolved tickets', () => {
  assert.equal(isBreached(ticket('Urgent'), t0 + 500 * MINUTE), true);
  assert.equal(isBreached(ticket('Urgent', { resolved: t0 + 500 * MINUTE }), t0 + 900 * MINUTE), false);
});

test('autoPriority raises but never lowers', () => {
  assert.equal(autoPriority('Payment Gateway Crash', 'Normal'), 'Urgent');
  assert.equal(autoPriority('PAYMENT FAILED again', 'Low'), 'Urgent');
  assert.equal(autoPriority('Cannot login to dashboard', 'Normal'), 'High');
  assert.equal(autoPriority('Cannot login to dashboard', 'Urgent'), 'Urgent');
  assert.equal(autoPriority('Question about invoices', 'Low'), 'Low');
  assert.equal(autoPriority('Crash', 'nonsense'), 'Urgent');
  assert.equal(autoPriority(undefined, 'High'), 'High');
});

test('formatDuration', () => {
  assert.equal(formatDuration(0), '0m');
  assert.equal(formatDuration(59 * MINUTE), '59m');
  assert.equal(formatDuration(125 * MINUTE), '2h 05m');
  assert.equal(formatDuration(-5 * MINUTE), '0m');
});

test('state machine: resolved tickets can only be reopened', () => {
  assert.deepEqual(TRANSITIONS.resolved, ['progress']);
  assert.ok(!TRANSITIONS.awaiting.includes('new'));
});
