import test from 'node:test';
import assert from 'node:assert/strict';
import { MINUTE } from '../shared/sla.js';
import { computeStats } from '../shared/stats.js';

const now = 1_700_000_000_000;
const mk = (o) => ({ id: 1, cat: 'Billing', pri: 'High', created: now - 100 * MINUTE, firstResponse: null, resolved: null, agentId: null, ...o });
const agents = [{ id: 1, display: 'Asha' }, { id: 2, display: 'Marcus' }];

test('empty data gives null averages instead of misleading numbers', () => {
  const s = computeStats([], agents, now);
  assert.equal(s.total, 0);
  assert.equal(s.slaCompliancePct, null);
  assert.equal(s.meanResponseMin, null);
});

test('compliance counts on-time resolutions against resolved plus open breaches', () => {
  const tickets = [
    mk({ id: 1, resolved: now - 50 * MINUTE }),                          // on time
    mk({ id: 2, created: now - 500 * MINUTE, resolved: now - 100 * MINUTE }), // late (High = 240m)
    mk({ id: 3, created: now - 300 * MINUTE }),                          // open and breached
    mk({ id: 4 }),                                                       // open and safe
  ];
  const s = computeStats(tickets, agents, now);
  assert.equal(s.openBreaches, 1);
  assert.equal(s.slaCompliancePct, 33); // 1 of 3
});

test('mean response time, categories and hourly buckets', () => {
  const tickets = [
    mk({ id: 1, firstResponse: now - 90 * MINUTE }),                        // 10 min
    mk({ id: 2, cat: 'Account', created: now - 30 * MINUTE, firstResponse: now - 10 * MINUTE }), // 20 min
    mk({ id: 3, cat: 'Account', created: now - 30 * 60 * MINUTE }),         // older than 24h
  ];
  const s = computeStats(tickets, agents, now);
  assert.equal(s.meanResponseMin, 15);
  assert.deepEqual(s.byCategory, { Billing: 1, Technical: 0, Account: 2, 'Feature Request': 0 });
  assert.equal(s.hourly.length, 24);
  assert.equal(s.hourly[23], 1);
  assert.equal(s.hourly[22], 1);
  assert.equal(s.hourly.reduce((a, b) => a + b, 0), 2);
});

test('agent efficiency index = on-time x 10 / (1 + avg hours)', () => {
  const tickets = [
    mk({ id: 1, agentId: 1, created: now - 200 * MINUTE, resolved: now - 140 * MINUTE }), // 1h, on time
    mk({ id: 2, agentId: 1, created: now - 200 * MINUTE, resolved: now - 80 * MINUTE }),  // 2h, on time
    mk({ id: 3, agentId: 1 }),                                                            // open
  ];
  const a = computeStats(tickets, agents, now).agents[0];
  assert.deepEqual([a.open, a.resolved, a.onTime, a.avgHours], [1, 2, 2, 1.5]);
  assert.equal(a.index, 8); // 20 / 2.5
  assert.equal(computeStats(tickets, agents, now).agents[1].index, 0);
});
